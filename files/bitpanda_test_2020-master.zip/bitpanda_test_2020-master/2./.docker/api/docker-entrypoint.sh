#!/bin/sh

set -eux

umask 0000

composer install --no-interaction

if [ ! -f .env ]; then 
    cp .env.example .env
    chown bitpanda:bitpanda .env 
fi

sed -i -E 's/(APP_URL=).*$/\1http:\/\/localhost:'"$APP_PORT"'/g' .env
sed -i -E 's/(DB_HOST=).*$/\1'"$MYSQL_HOST"'/g' .env
sed -i -E 's/(DB_DATABASE=).*$/\1bitpanda/g' .env
sed -i -E 's/(DB_USERNAME=).*$/\1bitpanda/g' .env
sed -i -E 's/(DB_PASSWORD=).*$/\1bitpanda/g' .env

while true
do
    nc -z $MYSQL_HOST 3306 && break
    echo "Waiting for MySQL dev instance to be ready ..."
    sleep 1
done

echo "MySQL dev instance is ready ... executing migrations"

php artisan migrate

exec "$@"
