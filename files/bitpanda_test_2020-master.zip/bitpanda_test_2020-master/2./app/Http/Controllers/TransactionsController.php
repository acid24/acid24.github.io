<?php
declare(strict_types=1);

namespace App\Http\Controllers;

use App\Dao\TransactionsDaoFactory;
use App\Http\Api\JsonResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use InvalidArgumentException;

class TransactionsController extends Controller
{
    use JsonResponseTrait;

    public function __invoke(Request $request): JsonResponse
    {
        try {
            $dao = TransactionsDaoFactory::get($request->query->get('source', 'db') ?: '');
        } catch (InvalidArgumentException $e) {
            return $this->badRequest('Invalid source');
        } catch (Exception $e) {
            return $this->internalError();
        }

        return $this->ok($dao->getAll());
    }
}
