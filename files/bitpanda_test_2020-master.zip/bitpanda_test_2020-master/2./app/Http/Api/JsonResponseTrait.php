<?php
declare(strict_types=1);

namespace App\Http\Api;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;

trait JsonResponseTrait
{
    private function success(int $code, array $data = null): JsonResponse
    {
        return response()
            ->json(['ok' => true, 'data' => $data], $code);
    }

    private function error(int $code, string $error = null, $details = null): JsonResponse
    {
        if (null !== $details && !is_array($details)) {
            $details = [(string)$details];
        }

        return response()
            ->json(['ok' => false, 'error' => $error, 'details' => $details], $code);
    }

    private function ok(array $data = null): JsonResponse
    {
        return $this->success(Response::HTTP_OK, $data);
    }

    private function badRequest(string $error, $details = null): JsonResponse
    {
        return $this->error(Response::HTTP_BAD_REQUEST, $error, $details);
    }

    private function internalError(): JsonResponse
    {
        return $this->error(Response::HTTP_INTERNAL_SERVER_ERROR, 'Internal server error');
    }
}
