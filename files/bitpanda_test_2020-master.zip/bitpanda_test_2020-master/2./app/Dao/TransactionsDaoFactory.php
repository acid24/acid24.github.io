<?php
declare(strict_types=1);

namespace App\Dao;

use InvalidArgumentException;

class TransactionsDaoFactory
{
    public static function get(string $source): TransactionsDao
    {
        if (!in_array(strtolower($source), TransactionsDao::ALLOWED_SOURCES)) {
            throw new InvalidArgumentException('Invalid source');
        }

        if ($source == TransactionsDao::SOURCE_DB) {
            return app()->make(DbTransactionsDao::class);
        }

        return app()->make(CsvTransactionsDao::class);
    }
}
