<?php
declare(strict_types=1);

namespace App\Dao;

use League\Csv\Reader;
use Traversable;

class CsvTransactionsDao implements TransactionsDao
{
    private const TRANSACTIONS_CSV = 'transactions.csv';
    private const CASTS = [
        'id' => 'int',
        'user_id' => 'int'
    ];

    private Reader $csvReader;

    public function __construct()
    {
        $this->csvReader = Reader::createFromPath(base_path() . '/' . self::TRANSACTIONS_CSV)
            ->setHeaderOffset(0);
    }

    public function getAll(): array
    {
        $records = $this->csvReader->getRecords();
        $normalizedRecords = $this->normalizeData($records);

        return iterator_to_array($normalizedRecords, false);
    }

    private function normalizeData(Traversable $records): Traversable
    {
        foreach ($records as $record) {
            $this->processRecord($record);
            yield $record;
        }
    }

    private function processRecord(&$record): void
    {
        foreach (self::CASTS as $key => $type) {
            if ($type == 'int' || $type = 'integer') {
                if (array_key_exists($key, $record)) {
                    $record[$key] = (int)$record[$key];
                }
            }
        }
    }
}
