<?php
declare(strict_types=1);

namespace App\Dao;

interface TransactionsDao
{
    const SOURCE_DB = 'db';
    const SOURCE_CSV = 'csv';

    const ALLOWED_SOURCES = [
        self::SOURCE_DB,
        self::SOURCE_CSV,
    ];

    public function getAll(): array;
}
