<?php
declare(strict_types=1);

namespace App\Dao;

use Illuminate\Support\Facades\DB;

class DbTransactionsDao implements TransactionsDao
{
    public function getAll(): array
    {
        return DB::select('select * from transactions');
    }
}
