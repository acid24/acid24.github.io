# Bitpanda PHP test 2020

### How to run solutions

There are two ways you can run both solutions each with its requirements:

1. Via docker (**recommended**)
1. Via a local PHP/MySQL installation

For method 1 you need to have [docker](https://www.docker.com/) and [docker-compose](https://docs.docker.com/compose/) installed. Optionally you will have a more pleasant experience if you have [make](https://www.gnu.org/software/make/#:~:text=GNU%20Make%20is%20a%20tool,compute%20it%20from%20other%20files.) installed.

For method 2 you need to have PHP 7.4 and MySQL 5.6 installed on your machine. In addition you also need to have [composer](https://getcomposer.org/) installed.

### Running the solutions with docker

#### Solution 1

After cloning the repository, if you **have** `make` installed, run the following commands

```bash
cd bitpanda_test_2020
cd 1./
make up
```

Docker will start downloading the necessary base images, build the solution's images and bring up the containers. This should take no more than 5 minutes even on a mediocre internet connection. After the base images are downloaded, local images are built and containers are up, there will still be a delay (~ 30 seconds) before you can make requests. This is because I wanted everything to be encapsulated (installing composer dependencies, creating necessary env files, running necessary migrations) and this takes a bit of time to get finished.

You can check if the containers are ready to receive connections by running

```bash
docker-compose logs api | grep 'ready to handle connections'
```
When the containers are ready to accept requests, import the file `Bitpanda.postman_collection.json` into Postman and everything should be setup. If you want to run the tests, execute the command

```bash
make tests
```

To clean up (bring containers down and remove them), run

```bash
make cleanup
```

If you **don't have** `make` installed, run the following commands

```bash
cd bitpanda_test_2020
cd 1./
docker-compose up -d
```

To run the tests, execute the command
```bash
docker-compose exec api php artisan test
```

To clean up (bring containers down and remove them), run

```bash
docker-compose down && docker system prune -f
```

#### Solution 2

If you **have** `make` installed, run the following commands

```bash
cd bitpanda_test_2020
cd 2./
make up
```
When the containers are ready to accept requests, import the file `Bitpanda.postman_collection.json` into Postman and everything should be setup

To clean up (bring containers down and remove them), run

```bash
make cleanup
```

If you **don't have** `make` installed, run the following commands

```bash
cd bitpanda_test_2020
cd 2./
docker-compose up -d
```

To clean up (bring containers down and remove them), run

```bash
docker-compose down && docker system prune -f
```

### Running the solutions via local PHP/MySQL installation

Running the solutions this way is a bit more involved. Follow these steps:

1. Clone the repository and navigate into the `bitpanda_test_2020` folder
1. Navigate to desired solution folder (either 1. or 2.)
1. Run `composer install` to install solution's dependencies
1. Create the `.env` and `.env.testing` (just for **solution 1**) files yourself and update the `DB_*` variables according to your MySQL setup
1. Run the migrations `php artisan migrate`
1. Start the web server `php artisan serve`
1. Import the file `Bitpanda.postman_collection.json` into Postman and you can start make requests
1. To run the tests (only for **solution 1**) run `php artisan test`
