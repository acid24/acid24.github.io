#!/bin/sh

set -eux

umask 0000

composer install --no-interaction

if [ ! -f .env ]; then 
    cp .env.example .env
    chown bitpanda:bitpanda .env 
fi

sed -i -E 's/(APP_URL=).*$/\1http:\/\/localhost:'"$APP_PORT"'/g' .env
sed -i -E 's/(DB_CONNECTION=).*$/\1'"$MYSQL_DEV_HOST"'/g' .env
sed -i -E 's/(DB_HOST=).*$/\1'"$MYSQL_DEV_HOST"'/g' .env
sed -i -E 's/(DB_DATABASE=).*$/\1bitpanda/g' .env
sed -i -E 's/(DB_USERNAME=).*$/\1bitpanda/g' .env
sed -i -E 's/(DB_PASSWORD=).*$/\1bitpanda/g' .env

while true
do
    nc -z $MYSQL_DEV_HOST 3306 && break
    echo "Waiting for MySQL dev instance to be ready ..."
    sleep 1
done

echo "MySQL dev instance is ready ... executing migrations"

php artisan migrate

if [ ! -f .env.testing ]; then 
    cp .env.example .env.testing
    chown bitpanda:bitpanda .env.testing 
fi

sed -i -E 's/(APP_URL=).*$/\1http:\/\/localhost:'"$APP_PORT"'/g' .env.testing
sed -i -E 's/(DB_CONNECTION=).*$/\1'"$MYSQL_TESTING_HOST"'/g' .env.testing
sed -i -E 's/(DB_HOST=).*$/\1'"$MYSQL_TESTING_HOST"'/g' .env.testing
sed -i -E 's/(DB_DATABASE=).*$/\1bitpanda/g' .env.testing
sed -i -E 's/(DB_USERNAME=).*$/\1bitpanda/g' .env.testing
sed -i -E 's/(DB_PASSWORD=).*$/\1bitpanda/g' .env.testing


while true
do
    nc -z $MYSQL_TESTING_HOST 3306 && break
    echo "Waiting for MySQL testing instance to be ready ..."
    sleep 1
done

echo "MySQL testing instance is ready ... executing migrations"

php artisan migrate --env=testing

exec "$@"
