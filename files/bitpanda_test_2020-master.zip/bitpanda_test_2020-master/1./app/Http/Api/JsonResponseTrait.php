<?php
declare(strict_types=1);

namespace App\Http\Api;

use Illuminate\Http\JsonResponse;

trait JsonResponseTrait
{
    public function success(int $code, array $data = null): JsonResponse
    {
        return response()
            ->json(['ok' => true, 'data' => $data], $code);
    }

    public function error(int $code, string $error = null, $details = null): JsonResponse
    {
        if (null !== $details && !is_array($details)) {
            $details = [(string)$details];
        }

        return response()
            ->json(['ok' => false, 'error' => $error, 'details' => $details], $code);
    }
}
