<?php
declare(strict_types=1);

namespace App\Http\Controllers;

use App\Dao\Criteria;
use App\Dao\UsersDao;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UsersController extends ApiController
{
    private UsersDao $usersDao;

    public function __construct(UsersDao $usersDao)
    {
        $this->usersDao = $usersDao;
    }

    public function __invoke(Request $request): JsonResponse
    {
        $errors = $this->validateInput($request->query->all());
        if (!empty($errors)) {
            return $this->badRequest('Invalid filters', $errors);
        }

        try {
            $criteria = Criteria::fromRequest($request);
            $users = $this->usersDao->getUsersSatisfying($criteria);
        } catch (Exception $e) {
            return $this->internalError();
        }

        return $this->ok(iterator_to_array($users));
    }

    private function validateInput(array $input): array
    {
        $errors = [];

        $validation = Validator::make($input, [
            'country' => 'nullable|regex:/^[a-z]{2,3}$/i'
        ]);
        if ($validation->fails()) {
            $errors = $validation->errors()->all();
        }

        return $errors;
    }
}
