<?php
declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Api\JsonResponseTrait;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;

class ApiController extends Controller
{
    use JsonResponseTrait;

    protected function ok(array $data = null): JsonResponse
    {
        return $this->success(Response::HTTP_OK, $data);
    }

    protected function badRequest(string $error, $details = null): JsonResponse
    {
        return $this->error(Response::HTTP_BAD_REQUEST, $error, $details);
    }

    protected function unprocessableEntity(string $error, $details = null): JsonResponse
    {
        return $this->error(Response::HTTP_UNPROCESSABLE_ENTITY, $error, $details);
    }

    protected function notFound(string $error): JsonResponse
    {
        return $this->error(Response::HTTP_NOT_FOUND, $error);
    }

    protected function internalError(): JsonResponse
    {
        return $this->error(Response::HTTP_INTERNAL_SERVER_ERROR, 'Internal server error');
    }
}
