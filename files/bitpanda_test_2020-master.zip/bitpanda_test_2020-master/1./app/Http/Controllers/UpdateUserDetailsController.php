<?php
declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\CitizenshipCountry;
use App\Models\UserDetails;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator as ValidationFacade;

class UpdateUserDetailsController extends ApiController
{
    public function __invoke(Request $request, int $id): JsonResponse
    {
        $errors = $this->validateInput($input = $request->json()->all());
        if (!empty($errors)) {
            return $this->badRequest('Invalid input', $errors);
        }

        $citizenshipCountryCode = strtoupper($request->input('citizenship_country'));
        $citizenshipCountry = CitizenshipCountry::firstWhere(strlen($citizenshipCountryCode) ? 'iso2' : 'iso3', $citizenshipCountryCode);
        if (null === $citizenshipCountry) {
            return $this->badRequest('Invalid input', sprintf('Unsupported citizenship country %s', $citizenshipCountryCode));
        }

        $details = UserDetails::firstWhere('user_id', $id);
        if (null === $details) {
            return $this->unprocessableEntity("Cannot update user details", "User with id $id has no details");
        }

        try {
            $details->fill($input + ['citizenship_country_id' => $citizenshipCountry->id]);
            $details->save();
        } catch (Exception $e) {
            return $this->internalError();
        }

        return $this->ok();
    }

    private function validateInput(array $input): array
    {
        $errors = [];

        $validation = ValidationFacade::make($input, [
            'citizenship_country' => 'required|string|regex:/^[a-z]{2,3}$/i',
            'first_name' => 'required|string|min:2',
            'last_name' => 'required|string|min:2',
            'phone_number' => 'required|string|digits_between:3,20'
        ]);

        if ($validation->fails()) {
            $errors = $validation->errors()->all();
        }

        return $errors;
    }
}
