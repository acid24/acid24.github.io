<?php
declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\User;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DeleteUserController extends ApiController
{
    public function __invoke(Request $request, int $id): JsonResponse
    {
        $user = User::with(['details'])->firstWhere('id', $id);
        if (null === $user) {
            return $this->notFound('User not found');
        }

        if (null !== $user->details) {
            return $this->unprocessableEntity("Cannot delete user", ["User with id $id has associated details"]);
        }

        try {
            $user->delete();
        } catch (Exception $e) {
            return $this->internalError();
        }

        return $this->ok();
    }
}
