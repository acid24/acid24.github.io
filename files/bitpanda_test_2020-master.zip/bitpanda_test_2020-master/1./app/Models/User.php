<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class User extends Model
{
    use HasFactory;

    protected $table = 'users';
    protected $attributes = [
        'active' => true
    ];
    protected $casts = [
        'id' => 'integer',
        'active' => 'boolean'
    ];

    public function details(): HasOne
    {
        return $this->hasOne(UserDetails::class);
    }
}
