<?php

namespace App\Exceptions;

use App\Http\Api\JsonResponseTrait;
use Exception;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Http\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class Handler extends ExceptionHandler
{
    use JsonResponseTrait;

    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     *
     * @return void
     */
    public function register()
    {
        $this->renderable(function (Exception $e) {
            switch (true) {
                case $e instanceof MethodNotAllowedHttpException:
                    return $this->error(Response::HTTP_METHOD_NOT_ALLOWED, 'Request method is not allowed');
                case $e instanceof NotFoundHttpException:
                    return $this->error(Response::HTTP_NOT_FOUND, 'Resource not found');
                case $e instanceof HttpException:
                    return $this->error($e->getStatusCode(), 'Unexpected HTTP exception');
                default:
                    return $this->error(Response::HTTP_INTERNAL_SERVER_ERROR, 'Internal server error');
            }
        });
    }
}
