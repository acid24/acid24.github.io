<?php
declare(strict_types=1);

namespace App\Dao;

use Illuminate\Http\Request;

final class Criteria
{
    private const PARAM_ACTIVE = 'active';
    private const PARAM_COUNTRY = 'country';

    private ?bool $active;
    private ?string $country;

    public static function fromRequest(Request $request): self
    {
        $active = null;
        if ($request->query->has(self::PARAM_ACTIVE)) {
            $active = $request->query->getBoolean(self::PARAM_ACTIVE);
        }

        $country = null;
        if ($request->query->has(self::PARAM_COUNTRY)) {
            $country = strtoupper($request->query->get(self::PARAM_COUNTRY));
        }

        $self = new self();
        $self->active = $active;
        $self->country = $country;

        return $self;
    }

    public function active(): ?bool
    {
        return $this->active;
    }

    public function country(): ?string
    {
        return $this->country;
    }

    public function isEmpty(): bool
    {
        $vars = array_filter(get_object_vars($this), function ($value): bool {
            return null !== $value;
        });

        return empty($vars);
    }

    public function isNotEmpty(): bool
    {
        return !$this->isEmpty();
    }
}
