<?php
declare(strict_types=1);

namespace App\Dao;

use Illuminate\Support\Facades\DB;
use Traversable;

class UsersDao
{
    public function getUsersSatisfying(Criteria $criteria): Traversable
    {
        $builder = DB::table('users')
            ->select('users.*');

        if ($criteria->isNotEmpty()) {
            $active = $criteria->active();
            if (null !== $active) {
                $builder->where('active', $active ? 1 : 0);
            }

            $country = $criteria->country();
            if (null !== $country) {
                $col = strlen($country) == 2 ? 'iso2' : 'iso3';

                $builder
                    ->join('user_details', 'users.id', '=', 'user_details.user_id')
                    ->join('countries', 'user_details.citizenship_country_id', '=', 'countries.id')
                    ->where("countries.$col", $country);
            }
        }

        return $builder->cursor();
    }
}
