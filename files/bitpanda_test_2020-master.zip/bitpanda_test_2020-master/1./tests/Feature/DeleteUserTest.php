<?php

namespace Tests\Feature;

use App\Models\CitizenshipCountry;
use App\Models\User;
use App\Models\UserDetails;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Response;
use Tests\TestCase;

class DeleteUserTest extends TestCase
{
    use RefreshDatabase;

    private const USER_ID = 100;
    private const ENDPOINT_URL = '/api/users/' . self::USER_ID;

    public function testDeleteSuccess()
    {
        User::factory()->state(['id' => self::USER_ID])->create();
        $this->assertDatabaseHas('users', ['id' => self::USER_ID]);

        $response = $this->delete(self::ENDPOINT_URL);
        $response->assertStatus(Response::HTTP_OK);

        $this->assertDatabaseMissing('users', ['id' => self::USER_ID]);
    }

    public function testUserNotFound()
    {
        $this->assertDatabaseMissing('users', ['id' => self::USER_ID]);

        $response = $this->delete(self::ENDPOINT_URL);
        $response->assertStatus(Response::HTTP_NOT_FOUND);
    }

    public function testUnprocessableEntity()
    {
        CitizenshipCountry::factory()->austria()->create();
        User::factory()->state(['id' => self::USER_ID])->create();
        UserDetails::factory()->state(['user_id' => self::USER_ID])->create();

        $this->assertDatabaseHas('user_details', ['user_id' => self::USER_ID]);
        $this->assertDatabaseHas('users', ['id' => self::USER_ID]);

        $response = $this->delete(self::ENDPOINT_URL);
        $response->assertStatus(Response::HTTP_UNPROCESSABLE_ENTITY);

        $this->assertDatabaseHas('user_details', ['user_id' => self::USER_ID]);
        $this->assertDatabaseHas('users', ['id' => self::USER_ID]);
    }
}
