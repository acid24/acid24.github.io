<?php

namespace Database\Factories;

use App\Models\CitizenshipCountry;
use Illuminate\Database\Eloquent\Factories\Factory;

class CitizenshipCountryFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CitizenshipCountry::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
        ];
    }

    public function austria()
    {
        return $this->state(function () {
            return [
                'id' => 10001,
                'name' => 'Austria',
                'iso2' => 'AT',
                'iso3' => 'AUT'
            ];
        });
    }

    public function germany()
    {
        return $this->state(function () {
            return [
                'id' => 10002,
                'name' => 'Germany',
                'iso2' => 'DE',
                'iso3' => 'DEU'
            ];
        });
    }
}
