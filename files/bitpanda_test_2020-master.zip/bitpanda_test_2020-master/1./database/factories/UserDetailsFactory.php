<?php

namespace Database\Factories;

use App\Models\User;
use App\Models\UserDetails;
use Illuminate\Database\Eloquent\Factories\Factory;

class UserDetailsFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UserDetails::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'user_id' => 1,
            'citizenship_country_id' => 10001,
            'first_name' => $this->faker->firstNameMale,
            'last_name' => $this->faker->lastName,
            'phone_number' => $this->faker->phoneNumber
        ];
    }
}
